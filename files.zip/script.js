// Dados de exemplo das imagens
const pins = [
    {
        id: 1,
        title: 'Sakura Dreams',
        description: 'Arte de cherry blossoms em estilo manga',
        image: 'https://images.unsplash.com/photo-1578926314433-deb5be1f39ff?w=400&h=500&fit=crop',
        color: '#D4637B'
    },
    {
        id: 2,
        title: 'Character Design',
        description: 'Personagem feminina com estilo anime moderno',
        image: 'https://images.unsplash.com/photo-1590080876590-ba0d9e72e4f1?w=400&h=500&fit=crop',
        color: '#B8506B'
    },
    {
        id: 3,
        title: 'Artistic Study',
        description: 'Estudos de expressão e olhares',
        image: 'https://images.unsplash.com/photo-1578301978162-7aae4d755744?w=400&h=500&fit=crop',
        color: '#D4637B'
    },
    {
        id: 4,
        title: 'Digital Art',
        description: 'Ilustração digital com cores vibrantes',
        image: 'https://images.unsplash.com/photo-1578926078328-123c10a3cbf0?w=400&h=500&fit=crop',
        color: '#B8506B'
    },
    {
        id: 5,
        title: 'Fashion Inspiration',
        description: 'Design de roupas e acessórios únicos',
        image: 'https://images.unsplash.com/photo-1580136579312-94651dfd596d?w=400&h=500&fit=crop',
        color: '#D4637B'
    },
    {
        id: 6,
        title: 'Portrait Study',
        description: 'Retrato artístico em estilo realista',
        image: 'https://images.unsplash.com/photo-1578926314433-deb5be1f39ff?w=400&h=500&fit=crop',
        color: '#B8506B'
    },
    {
        id: 7,
        title: 'Concept Art',
        description: 'Conceito visual de personagem fantástico',
        image: 'https://images.unsplash.com/photo-1590080876590-ba0d9e72e4f1?w=400&h=500&fit=crop',
        color: '#D4637B'
    },
    {
        id: 8,
        title: 'Color Study',
        description: 'Exploração de paletas de cores harmônicas',
        image: 'https://images.unsplash.com/photo-1578301978162-7aae4d755744?w=400&h=500&fit=crop',
        color: '#B8506B'
    },
    {
        id: 9,
        title: 'Manga Panel',
        description: 'Painel de manga tradicional em preto e branco',
        image: 'https://images.unsplash.com/photo-1578926078328-123c10a3cbf0?w=400&h=500&fit=crop',
        color: '#D4637B'
    }
];

// Estado de favoritos (armazenado em localStorage)
const favorites = JSON.parse(localStorage.getItem('favorites')) || {};

// Estado de mensagens das imagens
const imageMsgs = JSON.parse(localStorage.getItem('imageMsgs')) || {};

// Imagens carregadas pelo usuário
const userImages = JSON.parse(localStorage.getItem('userImages')) || [];

// Variável para rastrear a imagem atual aberta
let currentImageUrl = null;
let selectedColor = '#D4637B';

// Função para adicionar imagem ao localStorage
function addImageToStorage(base64Data, fileName) {
    const imageObj = {
        id: Date.now(),
        src: base64Data,
        name: fileName,
        timestamp: new Date().toISOString()
    };
    
    userImages.unshift(imageObj);
    localStorage.setItem('userImages', JSON.stringify(userImages));
    return imageObj;
}

// Função para processar arquivos
function processFiles(files) {
    Array.from(files).forEach(file => {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                addImageToStorage(e.target.result, file.name);
                renderGallery();
            };
            
            reader.readAsDataURL(file);
        }
    });
}

// Função para remover imagem
function removeImage(imageId) {
    const index = userImages.findIndex(img => img.id === imageId);
    if (index > -1) {
        userImages.splice(index, 1);
        localStorage.setItem('userImages', JSON.stringify(userImages));
        renderGallery();
    }
}

// Renderizar galeria
function renderGallery() {
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = '';

    // Renderizar imagens do usuário primeiro
    userImages.forEach((userImg) => {
        const pinElement = document.createElement('div');
        pinElement.className = 'pin';
        pinElement.innerHTML = `
            <div style="position: relative;">
                <img src="${userImg.src}" alt="${userImg.name}" class="pin-image">
                <div class="pin-overlay"></div>
                <div class="favorite-badge" data-pin="user-${userImg.id}">
                    <span class="count">${favorites[`user-${userImg.id}`] || 1}</span>
                </div>
        `;

        // Evento de clique com botão esquerdo
        pinElement.addEventListener('mousedown', (e) => {
            if (e.button === 0) {
                e.preventDefault();
                toggleFavorite(`user-${userImg.id}`);
            }
        });

        // Evento de clique na imagem para abrir modal
        const pinImage = pinElement.querySelector('.pin-image');
        pinImage.addEventListener('click', (e) => {
            e.stopPropagation();
            openModal(userImg.src);
        });

        gallery.appendChild(pinElement);
    });

    // Renderizar imagens padrões
    pins.forEach(pin => {
        const pinElement = document.createElement('div');
        pinElement.className = 'pin';
        pinElement.innerHTML = `
            <div style="position: relative;">
                <img src="${pin.image}" alt="${pin.title}" class="pin-image">
                <div class="pin-overlay"></div>
                <div class="favorite-badge" data-pin="${pin.id}">
                    <span class="count">${favorites[pin.id] || 1}</span>
                </div>
        `;

        // Evento de clique com botão esquerdo
        pinElement.addEventListener('mousedown', (e) => {
            if (e.button === 0) {
                e.preventDefault();
                toggleFavorite(pin.id);
            }
        });

        // Evento de clique na imagem para abrir modal
        const pinImage = pinElement.querySelector('.pin-image');
        pinImage.addEventListener('click', (e) => {
            e.stopPropagation();
            openModal(pin.image);
        });

        gallery.appendChild(pinElement);
    });
}

// Alternar favorito
function toggleFavorite(pinId) {
    // Incrementar ou inicializar favoritos
    if (!favorites[pinId]) {
        favorites[pinId] = 1;
    } else {
        favorites[pinId]++;
    }

    // Salvar no localStorage
    localStorage.setItem('favorites', JSON.stringify(favorites));

    // Atualizar UI com animação
    const badge = document.querySelector(`[data-pin="${pinId}"]`);
    if (badge) {
        const count = badge.querySelector('.count');
        count.textContent = favorites[pinId];

        // Remover classe ativa
        badge.classList.remove('active');

        // Forçar reflow para reiniciar animação
        void badge.offsetWidth;

        // Adicionar classe ativa
        badge.classList.add('active');

        // Remover após 2 segundos
        setTimeout(() => {
            badge.classList.remove('active');
        }, 2000);
    }
}

// Funções do Modal
function openModal(imageSrc) {
    const modal = document.getElementById('modal');
    const modalImage = document.getElementById('modalImage');
    const messageText = document.getElementById('messageText');
    const textEditor = document.getElementById('textEditor');
    const flipIndicator = document.getElementById('flipIndicator');
    
    currentImageUrl = imageSrc;
    modalImage.src = imageSrc;
    modalImage.classList.remove('flipped');
    flipIndicator.classList.remove('active');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Carregar mensagem existente se houver
    if (imageMsgs[imageSrc]) {
        messageText.value = imageMsgs[imageSrc].message;
        selectedColor = imageMsgs[imageSrc].color || '#D4637B';
        updateColorPresets();
    } else {
        messageText.value = '';
        selectedColor = '#D4637B';
        updateColorPresets();
    }
    
    // Fechar editor de texto ao abrir modal
    textEditor.classList.remove('active');
}

function closeModal() {
    const modal = document.getElementById('modal');
    const textEditor = document.getElementById('textEditor');
    modal.classList.remove('active');
    textEditor.classList.remove('active');
    document.body.style.overflow = 'auto'; // Allow scrolling
    currentImageUrl = null;
}

function flipImage() {
    const modalImage = document.getElementById('modalImage');
    const flipIndicator = document.getElementById('flipIndicator');
    modalImage.classList.toggle('flipped');
    flipIndicator.classList.toggle('active');
}

function toggleTextEditor() {
    const textEditor = document.getElementById('textEditor');
    textEditor.classList.toggle('active');
}

function updateColorPresets() {
    const presets = document.querySelectorAll('.color-preset');
    presets.forEach(preset => {
        const color = preset.getAttribute('data-color');
        if (color === selectedColor) {
            preset.classList.add('active');
        } else {
            preset.classList.remove('active');
        }
    });
}

function saveMessage() {
    const messageText = document.getElementById('messageText').value;
    
    if (currentImageUrl) {
        if (messageText.trim()) {
            imageMsgs[currentImageUrl] = {
                message: messageText,
                color: selectedColor
            };
        } else {
            delete imageMsgs[currentImageUrl];
        }
        
        localStorage.setItem('imageMsgs', JSON.stringify(imageMsgs));
        toggleTextEditor();
    }
}

// Inicializar
document.addEventListener('DOMContentLoaded', () => {
    renderGallery();

    // Fechar modal ao clicar no botão X
    const modalClose = document.getElementById('modalClose');
    modalClose.addEventListener('click', closeModal);

    // Fechar modal ao clicar fora da imagem
    const modal = document.getElementById('modal');
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Fechar modal com tecla ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal();
        }
    });

    // Botão de flip
    const flipBtn = document.getElementById('flipBtn');
    flipBtn.addEventListener('click', flipImage);

    // Botão de adicionar texto
    const textBtn = document.getElementById('textBtn');
    textBtn.addEventListener('click', toggleTextEditor);

    // Botão de salvar mensagem
    const saveMsgBtn = document.getElementById('saveMsgBtn');
    saveMsgBtn.addEventListener('click', saveMessage);

    // Botão de cancelar
    const cancelMsgBtn = document.getElementById('cancelMsgBtn');
    cancelMsgBtn.addEventListener('click', toggleTextEditor);

    // Seletor de cores
    const colorPresets = document.querySelectorAll('.color-preset');
    colorPresets.forEach(preset => {
        preset.addEventListener('click', (e) => {
            selectedColor = e.target.getAttribute('data-color');
            updateColorPresets();
        });
    });

    // Upload de imagens
    const uploadBtn = document.getElementById('uploadBtn');
    const uploadInput = document.getElementById('uploadInput');
    const dropZone = document.getElementById('dropZone');

    uploadBtn.addEventListener('click', () => {
        uploadInput.click();
    });

    uploadInput.addEventListener('change', (e) => {
        processFiles(e.target.files);
        uploadInput.value = ''; // Limpar input
    });

    // Drag and Drop
    document.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('active');
    });

    document.addEventListener('dragleave', (e) => {
        if (e.target === document || e.clientX === 0) {
            dropZone.classList.remove('active');
        }
    });

    document.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('active');
        processFiles(e.dataTransfer.files);
    });
});
